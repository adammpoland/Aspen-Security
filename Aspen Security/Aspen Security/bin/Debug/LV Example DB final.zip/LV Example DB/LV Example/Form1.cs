﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.Entity;
namespace LV_Example
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            using (AddressBookContext context = new AddressBookContext())
            {
                //List<Person> people = context.People.ToList();
                List<Person> people = context.People.OrderBy(rec => rec.Age).ThenBy(rec => rec.Name).ToList();
                //"from s in context.People where s.Name == "Darren" select s"
                //List<Person> people = context.People.Where(rec => rec.Age == 24).ToList();

                foreach (Person person in people)
                {
                    addPerson(person);
                }
                //Person Humphery = context.People.Where(rec => rec.Name == "Humphery").FirstOrDefault();
                //if (Humphery != null)
                //{
                //    addPerson(Humphery);
                //}

            }
                

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //Load Form
            AddPerson ap = new AddPerson();
            if (ap.ShowDialog() == DialogResult.OK)
            {
                //MessageBox.Show(ap.Age.ToString());
                //MessageBox.Show(ap.Bob.ToString());
                //MessageBox.Show(ap.Phone.ToString());
                //Doesn't do anything right now

                Person newPerson = new Person()
                {
                    Name = ap.Bob,
                    Age = ap.Age,
                    Phone = ap.Phone,
                    ImageIndex = ap.ImageIndex
                };
                addPerson(newPerson, true);
            
            }
            else
            {
                Console.WriteLine("Bad Results!");
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lvPeople.Items.Clear();
        }

        private void addPerson(Person person, bool newPerson = false)
        {
            if (newPerson == true)
            {
                using (AddressBookContext context = new AddressBookContext())
                {
                    context.People.Add(person);
                    context.SaveChanges();
                }
            }

            ListViewItem lvi = new ListViewItem();
            lvi.Text = person.Name; //(This is the 'name' property of our form)
            lvi.SubItems.Add(person.Age.ToString());
            lvi.SubItems.Add(person.Phone);
            lvi.SubItems.Add(person.ID.ToString());
            lvi.ImageIndex = (int)person.ImageIndex;
            lvPeople.Items.Add(lvi);
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (lvPeople.SelectedItems.Count == 1)
            {
                ListViewItem lvi = lvPeople.SelectedItems[0];

                InfoUpdate tmpFrm = new InfoUpdate();
                tmpFrm.Type = "name";
                tmpFrm.TextValue = lvi.Text;
                if (tmpFrm.ShowDialog() == DialogResult.OK)
                {
                    Person modPerson = new Person()
                    {
                        //Name = lvi.SubItems[0].Text,
                        Name = tmpFrm.TextValue,
                        Age = Convert.ToInt32(lvi.SubItems[1].Text),
                        Phone = lvi.SubItems[2].Text,
                        ID = Convert.ToInt32(lvi.SubItems[3].Text),
                        ImageIndex = lvi.ImageIndex
                    };
                    using(AddressBookContext context = new AddressBookContext())
                    {
                        //Connected Entity
                        //Person dbPerson = context.People.Where(s => s.ID == modPerson.ID).FirstOrDefault();
                        //if (dbPerson != null)
                        //{
                        //    dbPerson.Name = tmpFrm.TextValue;
                        //}

                        //Don't do both of these
                        //Disconnected Entity
                        context.Entry(modPerson).State = System.Data.Entity.EntityState.Modified;
                        context.SaveChanges();
                    }
                    lvi.Text = tmpFrm.TextValue;
                }
                    
            }
        }

        //Delete
        private void button1_Click(object sender, EventArgs e)
        {

            if (lvPeople.SelectedItems.Count == 1)
            {
                ListViewItem lvi = lvPeople.SelectedItems[0];

                Person delPerson = new Person()
                {
                    //Name = lvi.Text,
                    //Age = Convert.ToInt32(lvi.SubItems[1].Text),
                    //Phone = lvi.SubItems[2].Text,
                    ID = Convert.ToInt32(lvi.SubItems[3].Text)
                    //ImageIndex = lvi.ImageIndex
                };

                using (AddressBookContext context = new AddressBookContext())
                {
                    //Connected Entity
                    Person dbPerson = context.People.Where(s => s.ID == delPerson.ID).FirstOrDefault();
                    context.People.Remove(dbPerson);

                    //Disconnected Entity
                    //context.Entry(delPerson).State = System.Data.Entity.EntityState.Deleted;
                    context.SaveChanges();
                }

                lvPeople.Items.Remove(lvi);

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (AddressBookContext context = new AddressBookContext())
            {
                List<Family> families = context.Families
                    .Include(Family => Family.People).ToList();

                foreach (Family family in families)
                {
                    MessageBox.Show(family.Name);
                    foreach (Person curPers in family.People)
                    {
                        MessageBox.Show(curPers.Name);
                    }

                }

            }
        }
    }
}
