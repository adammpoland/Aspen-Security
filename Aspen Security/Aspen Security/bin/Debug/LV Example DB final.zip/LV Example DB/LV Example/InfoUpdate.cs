﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Needed to add
using System.Data.Entity;

namespace LV_Example
{
    public partial class InfoUpdate : Form
    {
        public InfoUpdate()
        {
            InitializeComponent();
        }

        private string type;

        public string Type
        {
            set
            {
                string Type = value;
                lblQuestion.Text = "What is the new " + Type + "?";
                this.Text = Type;
            }
        }

        private string textValue;

        public string TextValue
        {
            get
            {
                textValue = txtInfo.Text;
                return textValue;
            }
            set
            {
                textValue = value;
                txtInfo.Text = textValue;
                txtInfo.SelectAll();
            }
        }


    }
}
