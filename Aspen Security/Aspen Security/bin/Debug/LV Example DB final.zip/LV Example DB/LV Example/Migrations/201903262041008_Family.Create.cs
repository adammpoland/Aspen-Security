namespace LV_Example.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class FamilyCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Families",
                c => new
                    {
                        FamilyID = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                    })
                .PrimaryKey(t => t.FamilyID);
            
            AddColumn("dbo.People", "FamilyID", c => c.Int());
            CreateIndex("dbo.People", "FamilyID");
            AddForeignKey("dbo.People", "FamilyID", "dbo.Families", "FamilyID");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.People", "FamilyID", "dbo.Families");
            DropIndex("dbo.People", new[] { "FamilyID" });
            DropColumn("dbo.People", "FamilyID");
            DropTable("dbo.Families");
        }
    }
}
