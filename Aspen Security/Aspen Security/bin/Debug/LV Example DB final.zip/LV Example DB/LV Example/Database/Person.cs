﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LV_Example
{
    class Person
    {
        public int ID { get; set; }
        public string Name { set; get; }
        public Nullable<int> Age{ get; set; }
        public string Phone { get; set; }
        public Nullable<int> ImageIndex { get; set; }

        //Foreign key (Family)
        public Nullable<int> FamilyID { get; set; }
        public Family Family { get; set; }

    }
}
